/*-----------------------------------------------------
  main.c
  Kazubon 2001
-------------------------------------------------------*/

#include <windows.h>

/*------------------------------------------------
  entry point
--------------------------------------------------*/
BOOL WINAPI _DllMainCRTStartup(HANDLE hModule, DWORD dwFunction, LPVOID lpNot)
{
	return TRUE;
}

