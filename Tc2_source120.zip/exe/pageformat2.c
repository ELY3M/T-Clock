/*-------------------------------------------
  pageformat2.c
  "Detail of format" dialog
                       KAZUBON 1999
---------------------------------------------*/

#include "tclock.h"

