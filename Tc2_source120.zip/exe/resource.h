// icons and cursor
#define IDI_ICON1                       101
#define IDI_PLAY                        102
#define IDI_STOP                        103
#define IDI_DEL                         104
#define IDI_SNTP                        105
#define IDC_HAND                        106
